(function ($) {
	$(function () {
		$(".unslider").unslider();
	});

	$(".unslider").unslider();

})(jQuery);